## Github 个人网站

ChatGpt地址：https://sfvsfv.github.io/

## 注意
本站并不会收集你的KEY。相关信息，只属于你个人使用。即使你看到填写的KEY是暴露的，但是别人访问该网站是属于自己的一个新页面。
意味着，每个人都可以把它当作属于自己的网站使用即可。
## 使用方法
**使用前提：打开梯子。**
1. 填写自用的KEY，保存
2. 创建对话，正常聊天即可~

## 项目部署
步骤如下：
1. 下载本仓库打包后的源码
2. 使用GithubPages 部署即可

如果你不会部署，请找相关教程，或者只需要使用我的网站即可。
## 法律法规
请勿用于违反国家任何法律法规的行为，任何后果自行承担，与开发者本人无关。
## 公众号
公众号：（更多竞赛、项目源码发布）

![公众号](https://user-images.githubusercontent.com/62045791/224259546-d0bec9c4-12da-461e-aa1b-2336bb000ac9.jpg)

## 公用账号
MargaretMeghan746@outlook.com----Ykq35J4aJFS123----MvBnAGti----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

KristaGloria8679@outlook.com----vGY9s9ax----A8xgfQCm----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

